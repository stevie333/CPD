// Cross-platform development CMP3035M - Assignment 1.
// MAL12309806 - Stevie Mallyon.

// Puts the page in strict mode.
"use strict";

// When the device is ready.
function onDeviceReady() {
    console.log("device ready");
    // Initiate this function.
    innit();
    // Hides the preloader when the device is ready.
    $('.preloader').fadeOut('slow');

}

// When the document is ready to be loaded.
$(document).ready(function () {
    console.log("ready!");
    // Initiate this function.
    innit();
    // Hides the preloader when the document is ready.
    $('.preloader').fadeOut('slow');

});

// Function to determine if the device is online or offline.
function innit() {
    // Checks if online or offline.
    document.addEventListener("online", onOnline, false);
    document.addEventListener("offline", onOffline, false);

    // If online then the online function is loaded.
    if (window.navigator.onLine) {
        $('body').addClass('online');

    // If offline then the offline function is loaded.
    } else {
        $('body').addClass('offline');
    }

}

// When offline, remove the online class and add the offline class to the body.
function onOffline() {
    $('body').removeClass('online');
    $('body').addClass('offline');
}

// When online, remove the offline class and add the online class to the body.
function onOnline() {
    $('body').addClass('online');
    $('body').removeClass('offline');
}

// When the page is loaded force the title of the page to the settings below. This was needed because
// a problem was detected where the title set in HTML would set itself the H1 text in the header of the HTML.
$(document).on("pageshow", function () {
    document.title = "iShopping List";
});

// This is loaded when the home page is created.
$(document).on('pagecreate', '#home', function () {
    console.log("Home page created");

    // Variables to get elements from the HTML page.
    var itemInput = document.getElementById("item");
    var submit = document.getElementById("submit");
    var list = document.getElementById("listHolder");
    var wInfo = document.getElementById("welcomeInfo");
	var checkbox = document.createElement('input');
	checkbox.type = "checkbox";
	
    // Makes the welcome info text visible.
	wInfo.style.visibility = "visible";
	
    // Function when adding an item.
	function addItem() {
        // Hides the welcome info.
	    wInfo.style.visibility = "hidden";
        // Gets the input text values.
	    var currentItem = itemInput.value;
        // Creates a list element with the text from the input box.
	    var listItem = document.createElement("li");
        // Adds a checkbox next to the added list item.
	    listItem.innerHTML += checkbox.outerHTML + " " + currentItem;
        // Appends to the list.
	    list.appendChild(listItem);
        // The input box becomes empty once an entry has been added.
	    itemInput.value = "";
        // Calls the "store" function.
	    store();
        // An alert that the item has been added will be displayed.
        alert("Item added!");
        // Gets the current stored settings for the font size.
		var size = localStorage.getItem('font-size');
		$('#listHolder li').css({'font-size': size});
		console.log(size);

	    // Gets the current stored settings for the font colour.
		var col = localStorage.getItem('text-colour');
		$('#listHolder li').css({'color': col});
		console.log(col);
	}
    // Pressing the submit button calls the "addItem" function.
    submit.ontouchstart = addItem;

    // This is the code for delete list button.
    deleteButton.ontouchstart = function () {
        var txt;
        // Warning message is displayed.
        var conf = confirm("This will delete the entire list!");
        // If the confirmed thhe list will be deleted and the welcome message will be displayed again.
        if (conf == true) {
            txt = "Your list has been deleted!";
            list.innerHTML = "";
            itemInput.value = "";
            store();
            wInfo.style.visibility = "visible";
        // Else text saying you pressed cancel will be displayed.
        } else {
            txt = "You pressed Cancel!";
        }

    };

    // Function to store the current list items.
    function store() {
        window.localStorage.myitems = list.innerHTML;
    }

    // Function to get the current stored list entries.
    function getValues() {
        var storedValues = window.localStorage.myitems;
        console.log(storedValues);

        // If the values are not empty, load them and hide the welcome message text.
		if (storedValues != "") {
        	list.innerHTML = storedValues;
			wInfo.style.visibility = "hidden";
		}
        // If the values are empty, show the welcome message text.
		if (storedValues == null) {
        	list.innerHTML = " ";
			wInfo.style.visibility = "visible";
		}
    }
    
    // Calls the "getValues" function.
    getValues();

	
	// Gets the font size settings when the page is loaded.
	var size = localStorage.getItem('font-size');
	$('#listHolder li').css({'font-size': size});
	console.log(size);
	
    // Gets the font colour settings when the page is loaded.
	var col = localStorage.getItem('text-colour');
	$('#listHolder li').css({'color': col});
	console.log(col);

});

// This is loaded when the nearby page is created.
$(document).on('pagecreate', '#nearby', function () {
    console.log("Nearby page created");

    // Default to Hollywood, CA when no geolocation support.
    var defaultLatLng = new google.maps.LatLng(34.0983425, -118.3267434);

    if (navigator.geolocation) {
        function success(pos) {
            // Location found, show map with these coordinates.
            drawMap(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
        }
        function fail(error) {
            // Failed to find location, show default map.
            drawMap(defaultLatLng);
        }
        // Find the users current position, cache the location for 5 minutes, timeout after 6 seconds.
        navigator.geolocation.getCurrentPosition(success, fail, { maximumAge: 500000, enableHighAccuracy: true, timeout: 6000 });

    } else {
        // No geolocation support, show default map.
        drawMap(defaultLatLng);  
    }

    // Function to draw the map.
    function drawMap(latlng) {
        var myOptions = {
            zoom: 14,
            center: latlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };

        // Request local supermarkets within a 3000 radius.
        var request = {
            location: latlng,
            radius: "3000",
            type: ['supermarket']
        };

        // Puts the map into the map placeholder.
        var map = new google.maps.Map(document.getElementById("map"), myOptions);

        // Add an overlay to the map of current lat/lng.
        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
            label: 'You',
            title: 'You are here!'
        });

        // Access google maps places.
        var service = new google.maps.places.PlacesService(map);

        // nearby search request.
        service.nearbySearch(request, callback);

        // Function to get the supermarket information and place makers on each one.
        function callback(results, status) {
            console.log(results);

            // Place markers on each supermarket.
            if (status == google.maps.places.PlacesServiceStatus.OK) {
                var infowindow = new google.maps.InfoWindow();
                // For every result.
                for (var i = 0; i < results.length; i++) {
                    var marker2 = new google.maps.Marker({
                        position: results[i].geometry.location,
                        map: map

                    });

                    // Displays the nearest 5 supermarket results.
                    if (i < 5) {

                        // Rather than displaying a shops open status is "true" show the new text.
                        if (results[i].opening_hours.open_now == true) {
                            var status = "Store is Open";
                        }

                        // Rather than displaying a shops open status is "false" show the new text.
                        if (results[i].opening_hours.open_now == false) {
                            var status = "Store is Closed";
                        }

                        // Forms the text from extracted parts of the map data.
                        $("#mapResults").append("<br>" + results[i].name + " - " + results[i].vicinity + " - " + status + "<br>");

                    }


                }
            }
        }
    }


});


// This is loaded when the settings page is created.
$(document).on('pagecreate', '#settings', function () {
    console.log("Settings page created");
	
    // Set the new font size.
    $("#font-size").on("change", function () {
        $("#listHolder li").css({
            "font-size": $(this).val()
        });
		
        // Store the new CSS change.
		localStorage.setItem('font-size', $(this).val());
		console.log(localStorage.getItem('font-size'));
    });
	
    // Set the new font colour.
	$("#text-colour").on("change", function () {
	$("#listHolder li").css({
		"color": $(this).val()
		});
		
	    // Store the new CSS change.
		localStorage.setItem('text-colour', $(this).val());
		console.log(localStorage.getItem('text-colour'));
	});

    // When the default button is pressed, the default settings are set.
	$('#defaultButton').click(function () {
	    $('#listHolder li').css({
	        'color': 'black',
	        'font-size': '14px'
	    });

        // Saves the default settings in local storage so the CSS is changed.
	    localStorage.setItem('font-size', 'black');
	    localStorage.setItem('text-colour', '14px');
	    console.log(localStorage.getItem('font-size'));
	    console.log(localStorage.getItem('text-colour'));
	});
});